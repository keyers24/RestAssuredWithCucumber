package com.hotelreservations.services;

import com.hotelreservations.models.Auth;
import com.hotelreservations.models.Booking;
import com.hotelreservations.models.bookingDates;
import com.hotelreservations.models.bookingResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class reservationService extends baseTest{

/*    curl -X POST \
    https://restful-booker.herokuapp.com/auth \
            -H 'Content-Type: application/json' \
            -d '{
            "username" : "admin",
            "password" : "password123"
}'*/

    public  String generateToken(){
        Auth auth= new Auth("admin","password123");
        Response response = given(spec)
                .contentType(ContentType.JSON)
                .when()
                .body(auth)
                .post("/auth");

        response
                .then()
                .statusCode(200);

        return response.jsonPath().getJsonObject("token");


    }

    public bookingResponse createBooking(){
        bookingDates bookingdates = new bookingDates("2023-08-09","2023-09-07");
        Booking booking = new Booking("Ömer","Özdemir",57,true,bookingdates,"smokee");
        Response res = given(spec)
                .contentType(ContentType.JSON)
                .when()
                .body(booking)
                .post("/booking");
        res
                .then()
                .statusCode(200);
        return res.as(bookingResponse.class);
    }

    public void deleteReservation(String token, int bookingId)
    {
        Response res= given(spec)
                .contentType(ContentType.JSON)
                .header("cookie","token="+token)
                .when()
                .delete("/booking/"+bookingId);
        res
                .then()
                .statusCode(201);



    }

}
