package com.hotelreservations.steps;

import com.hotelreservations.models.bookingResponse;
import com.hotelreservations.services.reservationService;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;



public class updateReservationsSteps {
    reservationService reservationService;
    String Auth;

    bookingResponse bookingResponse;
    @Given("user is selected")
    public void userIsSelected() {
        reservationService=new reservationService();
        Auth=reservationService.generateToken();
        bookingResponse = reservationService.createBooking();

    }

    @When("user information is updated")
    public void userInformationIsUpdated() {
        reservationService.updateBooker(Auth,bookingResponse.getBookingid());
    }

    @And("the user is partially updated")
    public void theUserIsPartiallyUpdated() {
        reservationService.partlyUpdateBooker(Auth,bookingResponse.getBookingid());

    }

    @Then("it is verified that the user has been updated")
    public void itIsVerifiedThatTheUserHasBeenUpdated() {
        Assertions.assertEquals("Ömer",bookingResponse.getBooking().getFirstname());
    }
}
