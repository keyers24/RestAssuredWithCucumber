package com.hotelreservations.services;

import com.hotelreservations.models.*;
import io.cucumber.cienvironment.internal.com.eclipsesource.json.JsonObject;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class reservationService extends baseTest{

/*    curl -X POST \
    https://restful-booker.herokuapp.com/auth \
            -H 'Content-Type: application/json' \
            -d '{
            "username" : "admin",
            "password" : "password123"
}'*/

    public  String generateToken(){
        Auth auth= new Auth("admin","password123");
        Response response = given(spec)
                .contentType(ContentType.JSON)
                .when()
                .body(auth)
                .post("/auth");

        response
                .then()
                .statusCode(200);

        return response.jsonPath().getJsonObject("token");


    }

    public bookingResponse createBooking(){
        bookingDates bookingdates = new bookingDates("2023-08-09","2023-09-07");
        Booking booking = new Booking("Ömer","Özdemir",57,true,bookingdates,"smokee");
        Response res = given(spec)
                .contentType(ContentType.JSON)
                .when()
                .body(booking)
                .post("/booking");
        res
                .then()
                .statusCode(200);
        return res.as(bookingResponse.class);
    }

    public void deleteReservation(String token, int bookingId)
    {
        Response res= given(spec)
                .contentType(ContentType.JSON)
                .header("cookie","token="+token)
                .when()
                .delete("/booking/"+bookingId);
        res
                .then()
                .statusCode(201);



    }

/*    curl -X PUT \
    https://restful-booker.herokuapp.com/booking/1 \
            -H 'Content-Type: application/json' \
            -H 'Accept: application/json' \
            -H 'Cookie: token=abc123' \
            -d '{
            "firstname" : "James",
            "lastname" : "Brown",
            "totalprice" : 111,
            "depositpaid" : true,
            "bookingdates" : {
        "checkin" : "2018-01-01",
                "checkout" : "2019-01-01"
    },
            "additionalneeds" : "Breakfast"
}'*/

    public  void updateBooker(String token,int bookingId){
        bookingDates bookingdates=new bookingDates("2023-09-04","2023-09-09");
        Booking booking = new Booking("HGET","Ömer",5757,true,bookingdates,"dog bed");
        Response res= given(spec)
                .contentType(ContentType.JSON)
                .header("Cookie","token="+token)
                .body(booking)
                .when()
                .put("/booking/"+bookingId);
        res
                .then()
                .statusCode(200);

    }
/*    curl -X PATCH \
    https://restful-booker.herokuapp.com/booking/1 \
            -H 'Content-Type: application/json' \
            -H 'Accept: application/json' \
            -H 'Cookie: token=abc123' \
            -d '{
            "firstname" : "James",
            "lastname" : "Brown"
}'*/
    public void partlyUpdateBooker(String token,int bookingId){
        partlyBooking partlyBooking = new partlyBooking("HGET0","LAE");
        Response res= given(spec)
                .contentType(ContentType.JSON)
                .header("Cookie","token="+token)
                .body(partlyBooking)
                .when()
                .patch("/booking/"+bookingId);
        res
                .then()
                .statusCode(200);

    }

    //curl -i https://restful-booker.herokuapp.com/booking
    public void getbooking(int id)
    {
        Response res=given(spec)
                .when()
                .get("/booking/"+id);
        res
                .then()
                .statusCode(200);

    }
}
