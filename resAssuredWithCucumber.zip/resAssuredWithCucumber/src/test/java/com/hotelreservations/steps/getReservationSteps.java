package com.hotelreservations.steps;

import com.hotelreservations.models.bookingResponse;
import com.hotelreservations.services.reservationService;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class getReservationSteps {

    reservationService reservationService;
    bookingResponse bookingResponse;
    int bookingId;
    @Given("The user enters the user information they want to see")
    public void Entersinformaiton() {
        reservationService=new reservationService();
        bookingResponse=reservationService.createBooking();
        bookingId=bookingResponse.getBookingid();
        

    }


    @When("Making user request")
    public void makingUserRequest() {
        reservationService.getbooking(bookingId);
    }

    @Then("displaying the relevant user")
    public void displayingTheRelevantUser() {
        Assertions.assertEquals("Ömer",bookingResponse.getBooking().getFirstname());
    }
}
