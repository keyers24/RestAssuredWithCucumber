package com.hotelreservations.steps;

import com.hotelreservations.models.bookingResponse;
import com.hotelreservations.services.reservationService;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

public class reservationSteps {
    reservationService reservationService;
    String Auth;
    bookingResponse bookingResponse;
    @Given("user creates a new reservation")
    public void userCreatesANewReservation() {
        reservationService=new reservationService();
    }

    @And("the user provides the information needed for booking")
    public void theUserProvidesTheInformationNeededForBooking() {
        Auth=reservationService.generateToken();
    }

    @When("user generates hotel bookings")
    public void userGeneratesHotelBookings() {
         bookingResponse = reservationService.createBooking();
    }

    @Then("The reservation appears to have been created successfully")
    public void theReservationAppearsToHaveBeenCreatedSuccessfully() {
        Assertions.assertEquals("Ömer",bookingResponse.getBooking().getFirstname());
        Assertions.assertEquals("Özdemir",bookingResponse.getBooking().getLastname());
        Assertions.assertEquals(57,bookingResponse.getBooking().getTotalprice());
        Assertions.assertEquals(true,bookingResponse.getBooking().isDepositpaid());
        Assertions.assertEquals("smokee",bookingResponse.getBooking().getAdditionalneeds());


    }

    @And("User cancels the reservation created")
    public void userCancelsTheReservationCreated() {
        reservationService.deleteReservation(Auth,bookingResponse.getBookingid());
    }



}
